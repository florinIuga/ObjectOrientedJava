package game;
public final class Asset {

    private int id;
    private String assetName;
    private boolean legal;
    private int profit;
    private int penalty;
    private static final int APPLE_PROFIT = 2;
    private static final int CHEESE_PROFIT = 3;
    private static final int BREAD_PROFIT = 4;
    private static final int CHICKEN_PROFIT = 4;
    private static final int SILK_PROFIT = 9;
    private static final int PEPPER_PROFIT = 8;
    private static final int BARREL_PROFIT = 7;
    private static final int LEGAL_PENALTY = 2;
    private static final int ILLEGAL_PENALTY = 4;
    private static final int SILK_ID = 10;
    private static final int PEPPER_ID = 11;
    private static final int BARREL_ID = 12;
    private static final int CHICKEN_ID = 3;

    public Asset(final int idPlayer) {
        switch (idPlayer) {

        case 0:
            id = idPlayer;
            assetName = "Apple";
            legal = true;
            profit = APPLE_PROFIT;
            penalty = LEGAL_PENALTY;
            break;
        case 1:
            id = idPlayer;
            assetName = "Cheese";
            legal = true;
            profit = CHEESE_PROFIT;
            penalty = LEGAL_PENALTY;
            break;
        case 2:
            id = idPlayer;
            assetName = "Bread";
            legal = true;
            profit = BREAD_PROFIT;
            penalty = LEGAL_PENALTY;
            break;
        case CHICKEN_ID:
            id = idPlayer;
            assetName = "Chicken";
            legal = true;
            profit = CHICKEN_PROFIT;
            penalty = LEGAL_PENALTY;
            break;
        case SILK_ID:
            id = idPlayer;
            assetName = "Silk";
            legal = false;
            profit = SILK_PROFIT;
            penalty = ILLEGAL_PENALTY;
            break;
        case PEPPER_ID:
            id = idPlayer;
            assetName = "Pepper";
            legal = false;
            profit = PEPPER_PROFIT;
            penalty = ILLEGAL_PENALTY;
            break;
        case BARREL_ID:
            id = idPlayer;
            assetName = "Barrel";
            legal = false;
            profit = BARREL_PROFIT;
            penalty = ILLEGAL_PENALTY;
            break;
         default:

        }
    }
    // overrides the equals method for removeAll()
    public boolean equals(final Object object) {
        if (!(object instanceof Asset)) {
            return false;
        }
        Asset otherMember = (Asset) object;
        return otherMember.id == this.id;
    }

    public int getProfit() {
        return this.profit;
	}

    public int getPenalty() {
        return this.penalty;
    }

    public boolean isLegal() {
        return this.legal;
    }

    public int getID() {
        return this.id;
    }

    public String getAssetName() {
        return this.assetName;
    }

    public int getIdOf(final String asset) {
      int idWanted = 0;
        if (this.assetName.equals(asset)) {
           idWanted = this.id;
         }
       return idWanted;
     }

    public String toString() {
        return this.assetName;
    }
}
