package game;
import java.util.Comparator;

public final class AssetComparator implements Comparator<Asset> {

    @Override
	public int compare(final Asset a1, final Asset a2) {
		return a2.getProfit() - a1.getProfit();
	}

}
